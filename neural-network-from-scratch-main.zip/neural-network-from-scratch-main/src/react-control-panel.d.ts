declare module 'react-control-panel';
